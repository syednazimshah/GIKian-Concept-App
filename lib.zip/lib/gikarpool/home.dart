import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);
  @override
  FormState createState() {
    return FormState();
  }
}

class FormState extends State<Home> {
  final formKey = GlobalKey<FormState>();
  TextEditingController name = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController regno = TextEditingController();
  @override
  void initState() {
    super.initState();
    getvalues();
  }

  Future getvalues() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    name.text = prefs.getString('name') ?? '';
    phone.text = prefs.getString('phone') ?? '';
    regno.text = prefs.getString('reg') ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        height: MediaQuery.of(context).size.height,
        //color: Colors.blue.shade300,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: ListView(
            key: formKey,
            shrinkWrap: true,
            children: <Widget>[
              const Text(
                'Your Details',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 30.0,),
              ),
              const SizedBox(
                height: 70,
              ),
              TextFormField(
                enabled: false,
                controller: name,
                decoration: const InputDecoration(
                  filled: true,
                  fillColor: Color(0xFFD3F2FD),
                  border:OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Color(0xFFD3F2FD), style: BorderStyle.none),
                      borderRadius: BorderRadius.all(Radius.circular(50))),
                  icon: Icon(Icons.person_sharp, color: Colors.blue),
                  // labelStyle: TextStyle(fontSize: 25)
                ),
                onChanged: (value) {},
              ),
              const SizedBox(height: 40),
              TextFormField(
                enabled: false,
                controller: phone,
                decoration: const InputDecoration(
                  filled: true,
                  fillColor: Color(0xFFD3F2FD),
                  border:OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Color(0xFFD3F2FD), style: BorderStyle.none),
                      borderRadius: BorderRadius.all(Radius.circular(50))),


                  icon: Icon(Icons.phone, color: Colors.blue),
                ),
                onChanged: (value) {},
              ),
              const SizedBox(height: 40),
              TextFormField(
                enabled: false,
                controller: regno,
                decoration: const InputDecoration(
                  filled: true,
                  fillColor: Color(0xFFD3F2FD),
                  border:OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Color(0xFFD3F2FD), style: BorderStyle.none),
                      borderRadius: BorderRadius.all(Radius.circular(50))),
                  icon: Icon(Icons.perm_contact_cal, color: Colors.blue),
                ),
                onChanged: (value) {},
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),

    );
  }
}
