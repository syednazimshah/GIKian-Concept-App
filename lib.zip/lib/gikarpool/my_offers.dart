
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'error_screen.dart';
import 'package:intl/intl.dart';
import 'update_document.dart';
import 'loading.dart';

class MyOffers extends StatefulWidget {
  final String Reg;
  const MyOffers({
    Key? key,
    required this.Reg,
  }) : super(key: key);

  @override
  _MyOffersState createState() => _MyOffersState();
}

class _MyOffersState extends State<MyOffers> {
  bool checknet = true;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('001')
          .orderBy("DateAndTime", descending: true)
          .where('RegNo', isEqualTo: widget.Reg)
          .snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return const Error();
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Loading();
        }
        if (snapshot.data!.docs.isEmpty) {
          return Scaffold(
                appBar: AppBar(
                  centerTitle: true,
                  elevation: 0,
                  title: const Text('My Offered rides'),
                ),
                body: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.error_outline_rounded),
                      SizedBox(
                        height: 5,
                      ),
                      Text('No Rides Offered')
                    ],
                  ),
                ));
        }
        return Scaffold(
            appBar: AppBar(

              centerTitle: true,
              elevation: 0,
              title: const Text('My Offered rides'),
            ),
            body: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: ListView(
                shrinkWrap: true,
                children: snapshot.data!.docs.map((DocumentSnapshot document) {
                  final docId = document.id;
                  Map<String, dynamic> data =
                      document.data()! as Map<String, dynamic>;
                  return Container(
                      child: Card(
                          color: Colors.blue.shade50,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(24)),
                          elevation: 5,
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: <Widget>[
                                Center(
                                  child: Column(
                                        children: <Widget>[
                                          (data['FromOrTo'])
                                              ? Row(children: <Widget>[
                                                  const SizedBox(
                                                    height: 5,
                                                  ),
                                                  const Text(
                                                    'GIKI  ',
                                                    style: TextStyle(
                                                        fontSize: 20,
                                                        fontWeight:
                                                            FontWeight.w600),
                                                  ),
                                                  const Icon(Icons
                                                      .arrow_forward_outlined),
                                                  Text(
                                                    '  ${data['City'].toString()}',
                                                    style: const TextStyle(
                                                        fontSize: 20,
                                                        fontWeight:
                                                            FontWeight.w600),
                                                  )
                                                ])
                                              : Row(children: <Widget>[
                                                  const SizedBox(
                                                    height: 5,
                                                  ),
                                                  Text(
                                                    '${data['City'].toString()}  ',
                                                    style: const TextStyle(
                                                        fontSize: 20,
                                                        fontWeight:
                                                            FontWeight.w600),
                                                  ),
                                                  const Icon(Icons
                                                      .arrow_forward_outlined),
                                                  const Text('  GIKI',
                                                      style: TextStyle(
                                                          fontSize: 20,
                                                          fontWeight:
                                                              FontWeight.w600))

                                                ]),
                                          const SizedBox(height: 10),
                                          Text(
                                            DateFormat.yMMMMEEEEd()
                                                .add_jm()
                                                .format(data['DateAndTime']
                                                .toDate()),
                                            style:
                                            const TextStyle(fontSize: 12),
                                          )
                                        ],
                                      ),
                                ),
                                Column(
                                  children: <Widget>[
                                    IconButton(
                                      icon: const Icon(
                                        Icons.delete,
                                        color: Colors.blue,
                                      ),
                                      onPressed: () => showDialog<String>(
                                        context: context,
                                        builder: (BuildContext context) =>
                                            AlertDialog(
                                          title: const Text('Remove Offer'),
                                              shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(24)),
                                          content: const Text(
                                              'Do You Want To Delete This Offered Ride?'),
                                          actions: <Widget>[
                                            TextButton(
                                              onPressed: () => Navigator.pop(
                                                  context),
                                              child: const Text('CANCEL'),
                                            ),
                                            TextButton(
                                              onPressed: () async {
                                                if (!await InternetConnectionChecker().hasConnection) {Navigator.push(context, PageRouteBuilder(pageBuilder: (context,_,__) => const Error(),transitionDuration: Duration(seconds: 0)));}
                                                else {
                                                  Navigator.pop(context);
                                                  await FirebaseFirestore.instance.collection('001').doc(docId).delete();
                                                }
                                              },
                                              child: const Text('DELETE'),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    IconButton(
                                      icon: const Icon(
                                        Icons.edit,
                                        color: Colors.blue,
                                      ),
                                      onPressed: () {
                                        showDialog(context: context, builder: (context) {
                                          return StatefulBuilder(
                                              builder: (context, setState) {
                                                return SimpleDialog(
                                                  title: Center(child: Text('You can only change\nthe available seats',style: TextStyle(color: Colors.blue),)),
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.circular(24)),
                                                  children: [
                                                   UpdateDocument(documentId: docId),
                                                  ],
                                                );
                                              });
                                        });
                                      }
                                    )
                                  ],
                                ),
                              ])));
                }).toList(),
              ),
            ),
          );
      },
    );
  }
}
