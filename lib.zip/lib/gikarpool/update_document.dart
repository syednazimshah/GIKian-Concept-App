import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:numberpicker/numberpicker.dart';
import 'error_screen.dart';
import 'package:flutter_number_picker/flutter_number_picker.dart';
import 'loading.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

class UpdateDocument extends StatefulWidget {
  final String documentId;

  const UpdateDocument({
    Key? key,
    required this.documentId,
  }) : super(key: key);

  @override
  _UpdateDocumentState createState() => _UpdateDocumentState();
}

class _UpdateDocumentState extends State<UpdateDocument> {
  String newSeats = '1';

  @override
  Widget build(BuildContext context) {
    CollectionReference users = FirebaseFirestore.instance.collection('001');

    return FutureBuilder<DocumentSnapshot>(
      future: users.doc(widget.documentId).get(),
      builder:
          (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshot) {
        if (snapshot.hasError) {
          return const Error();
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Loading();
        }
        if (snapshot.hasData && !snapshot.data!.exists) {
          return const Error();
        }

        if (snapshot.connectionState == ConnectionState.done) {
          Map<String, dynamic> data =
              snapshot.data!.data() as Map<String, dynamic>;
          return Center(
              child: Column(
            children: <Widget>[
              const SizedBox(
                height: 30,
              ),
              Text('Seats Available: ${data['Seats']}',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  )),
              const SizedBox(
                height: 30,
              ),
              const Text('Pick new available seats',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(
                height: 50,
              ),

              NumberPicker(
                  minValue: 1,
                  maxValue: 16,
                  value: int.parse(newSeats),
                  haptics: true,
                  onChanged: (int value) =>
                        newSeats = value.toString()
                      ),
              // NumberPicker(
              //         value: newSeats,
              //         step: 1,
              //         minValue: 1,
              //         maxValue: 16,
              //         initialValue: 1,
              //         onValue: (value) {
              //           newSeats = value.toString();
              //         }),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('Cancel')),
                  SizedBox(width: 20),
                  ElevatedButton(
                      onPressed: () async {
                        if (!await InternetConnectionChecker().hasConnection) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const Error()));
                        } else {
                          await FirebaseFirestore.instance
                              .collection('001')
                              .doc(widget.documentId)
                              .update({'Seats': int.parse(newSeats)});
                          Navigator.pop(context);
                          showDialog(
                              context: context,
                              builder: (context) {
                                return StatefulBuilder(
                                    builder: (context, setState) {
                                  return SimpleDialog(
                                    title: Center(
                                        child: Text(
                                      'Successful!',
                                      style: TextStyle(color: Colors.blue),
                                    )),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(24)),
                                    children: [
                                      Column(
                                        children: <Widget>[
                                          Center(
                                            child: Icon(
                                              Icons
                                                  .check_circle_outline_rounded,
                                              size: 80,
                                              color: Colors.green,
                                            ),
                                          ),
                                          SizedBox(
                                            height: 15,
                                          ),
                                          Center(
                                              child: Text(
                                            'Seats Updated!',
                                            style: TextStyle(fontSize: 20),
                                          )),
                                        ],
                                      ),
                                    ],
                                  );
                                });
                              });
                        }
                      },
                      child: Text('Update Seats'))
                ],
              ),
            ],
          ));
        }
        return Loading();
      },
    );
  }
}
