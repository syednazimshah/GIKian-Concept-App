import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'orderdata.dart';
import 'package:untitled/user/loading.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'orderhistory.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:untitled/error screen/errorscreen.dart';

class OrderScreen extends StatefulWidget {
  orderlist newlist = new orderlist();
  final String collectionKEY;

  OrderScreen({Key? key, required this.newlist, required this.collectionKEY})
      : super(key: key);

  @override
  OrderScreenState createState() {
    return OrderScreenState();
  }
}

class OrderScreenState extends State<OrderScreen> {
  TextEditingController _name = TextEditingController();
  TextEditingController _phone = TextEditingController();
  TextEditingController _address = TextEditingController();
  TextEditingController _reg = TextEditingController();
  bool initialized = false;
  bool checknet = true;

  @override
  void initState() {
    super.initState();
    InternetConnectionChecker().onStatusChange.listen((event) {
      final hasnet = event == InternetConnectionStatus.connected;
      setState(() {
        checknet = hasnet;
      });
    });
    getvalues().whenComplete(() => setState(() {
          initialized = true;
        }));
  }

  String order() {
    var temp = StringBuffer();
    widget.newlist.datalist.forEach((element) {
      temp.write('\n');
      temp.write(element.number.toString());
      temp.write(' ');
      temp.write(element.name);
    });
    return temp.toString().replaceFirst('\n', '', 0);
  }

  Future getvalues() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    _name.text = prefs.getString('name') ?? '?';
    _phone.text = prefs.getString('phone') ?? '?';
    _address.text = prefs.getString('address') ?? '?';
    _reg.text = prefs.getString('reg') ?? '?';
    await Firebase.initializeApp();
  }

  @override
  Widget build(BuildContext context) {
    if (!checknet) {
      return Error();
    } else {
      if (initialized) {
        return Scaffold(
          appBar: AppBar(
            title: Text('Place your Order'),
            centerTitle: true,
          ),
          body: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: ListView(
              shrinkWrap: true,
              children: <Widget>[
                Center(
                  child: Text(
                    (_name.text == '?' ||
                            _phone.text == '?' ||
                            _address.text == '?'||_reg.text=='?')
                        ? 'One or more fields are missing!\nPlease update your Info in the Settings!'
                        : 'Your Information',
                    style: TextStyle(
                      fontSize: 20,
                      color: (_name.text == '?' ||
                              _phone.text == '?' ||
                              _address.text == '?'||_reg.text=='?')
                          ? Colors.red
                          : Colors.black,
                    ),
                  ),
                ),
                Card(
                  color: Colors.blue.shade50,
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    children: <Widget>[
                      SizedBox(height: 10),
                      Center(
                        child: Text(
                          'Name: ${_name.text}',
                          softWrap: true,
                          style: TextStyle(
                            fontSize: 17,
                            color:
                                (_name.text == '?') ? Colors.red : Colors.black,
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Center(
                        child: Text(
                          'Contact: ${_phone.text}',
                          softWrap: true,
                          style: TextStyle(
                            fontSize: 17,
                            color: (_phone.text == '?')
                                ? Colors.red
                                : Colors.black,
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Center(
                        child: Text(
                          'Reg: ${_reg.text}',
                          softWrap: true,
                          style: TextStyle(
                            fontSize: 17,
                            color: (_reg.text == '?')
                                ? Colors.red
                                : Colors.black,
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Center(
                        child: Text(
                          'Address: ${_address.text}',
                          softWrap: true,
                          style: TextStyle(
                            fontSize: 17,
                            color: (_address.text == '?')
                                ? Colors.red
                                : Colors.black,
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Center(
                  child: Text(
                    'Your Order Below',
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                ),
                Card(
                  color: Colors.blue.shade50,
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text(
                          order(),
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Center(
                  child: Text(
                    'Total: Rs.${widget.newlist.totalprice}',
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                        onPressed: () {
                            Navigator.pop(context);
                            widget.newlist.datalist.clear();
                            widget.newlist.totalorders = 0;
                            widget.newlist.totalprice = 0;
                            Navigator.pop(context);
                            Navigator.pop(context);
                        },
                        child: Text('Cancel Order')),
                    SizedBox(width: 20),
                    ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('Go Back')),
                    SizedBox(width: 20),
                    Builder(
                      builder: (context) => ElevatedButton(
                        child: Text('Place Order'),
                        onPressed: (_name.text == '?' ||
                                _phone.text == '?' ||
                                _address.text == '?' ||
                                order().isEmpty ||
                                order() == '' ||
                                !checknet||_reg.text=='?')
                            ? null
                            : () async {
                                FirebaseFirestore.instance
                                    .collection(widget.collectionKEY)
                                    .doc('orders')
                                    .collection('orders')
                                    .add(<String, dynamic>{
                                  'text': order(),
                                  'timestamp': DateTime.now(),
                                  'location': _address.text,
                                  'phone': _phone.text,
                                  'reg':_reg.text,
                                  'name': _name.text,
                                  'price': widget.newlist.totalprice,
                                  'received': false,
                                });
                                setState(() {
                                  widget.newlist.datalist.clear();
                                  widget.newlist.totalprice = 0;
                                  widget.newlist.totalorders = 0;
                                });
                                Navigator.pushReplacement(
                                    context,
                                    PageRouteBuilder(
                                      pageBuilder: (context, __, ___) =>
                                          OrderHistory(
                                        collectionKEY: widget.collectionKEY,
                                      ),
                                      transitionDuration: Duration(seconds: 0),
                                    ));
                              },
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        );
      }
      return Loading();
    }
  }
}
